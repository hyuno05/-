JourneyMap + Cobblemon Pokemon Tracking - Fabric 1.21.1

클라이언트 전용 모드 패키지입니다.

1. 이 ZIP 안의 모든 JAR을 클라이언트 mods 폴더에 넣으세요.
2. Minecraft 1.21.1 / Fabric Loader 0.20.1 프로필로 실행하세요.
3. JourneyMap에서 포켓몬 종을 선택하면 선택한 야생 포켓몬의 실시간 위치를 지도와 미니맵에서 추적할 수 있습니다.
4. 서버 mods 폴더에는 넣지 않아도 됩니다.

필수 구성:
- JourneyMap 6.0.9
- Cobblemon JEI & JourneyMap Integration 1.10.2
- Just Enough Items 19.70.0.469
- Fabric Language Kotlin 1.14.2
- Fabric API, Architectury API
